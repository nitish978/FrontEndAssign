from django.shortcuts import render
from .models import Daily_expenses
from django.http import HttpResponse
from django.utils import timezone
import datetime
from datetime import datetime

def index(request):
    #s=Daily_expenses.objects.all()
    #html=''
    #for s1 in s:
     #  html+= '<h3>'+str(s1.grocery)+'</h3><br>'
      # html+= '<h3>'+str(s1.entertainment)+'</h3><br>'
       #html+= '<h3>'+str(s1.vehicle)+'</h3></br>'
       #html+= '<h3>'+str(s1.food)+'</h3>'
    #return HttpResponse(html)
     return render(request,'record/index.html')
def add(request):
     return render(request,'record/form.html')
def adddata(request):
     error = False
     if request.POST:
           if 'grocery' in request.POST:
                 grocery=request.POST.get('grocery')
           else:
             error=True
           if 'entertainment' in request.POST:
                 entertainment=request.POST.get('entertainment')
           else:
             error=True
           if 'vehicle' in request.POST:
                 vehicle=request.POST.get('vehicle')
           else:
             error=True
           if 'food' in request.POST:
                 food=request.POST.get('food')
           else:
             error=True
           if 'miscellaneous' in request.POST:
                 miscellaneous=request.POST.get('miscellaneous')
           else:
             error=True
           date1=datetime.now().date()           
           if not error:
              q=Daily_expenses(grocery=grocery,entertainment=entertainment,vehicle=vehicle,food=food,miscellaneous=miscellaneous,date=date1)
              q.save()
              return render(request,'record/index.html')
           else:
              return render(request,'record/form.html')
     else:
        return render(request,'record/form.html')


def graph1(request):
      date=datetime.now().date()
      data= Daily_expenses.objects.filter(date=date)
      x='DAILY BASIS DATA VISUALIZATION ON BAR GRAPH'
      return render(request,'record/bargraph.html',{'data':data,'title':x})
def add1(request):
     return render(request,'record/monthaly_graph.html')
def display(request):
     return render(request,'record/list.html')
def monthaly_basis_graph(request):
    error = False
    if request.POST:
           if 'startdate' in request.POST:
                 start_date=request.POST.get('startdate')
           else:
             error=True
           if 'enddate' in request.POST:
                 end_date=request.POST.get('enddate')
           else:
             error=True
           x='MONTHLY BASIS DATA VISUALIZATION ON BAR GRAPH'
           #f_start_date=start_date.strftime("%Y-%m-%d")
           #f_end_date=end_date.strftime("%Y-%m-%d")
           if not error:
                t = Daily_expenses.objects.filter(date__range=[start_date,end_date])    
                return render(request,'record/bargraph.html',{'data':t,'title':x})
           else:
                return render(request,'record/index.html')  
    else:
          return render(request,'record/index.html')
                
                
def check_req(request):
         error = False
         if request.GET:   
           if 'check' in request.GET:
                 result=request.GET.get('check')
           else:
             error=True
           if not error:
                  date=datetime.now().date()
                  t = Daily_expenses.objects.filter(date=date)
                  x=""
                  y=0   
                  if result=="grocery":
                        x="Total expense on grocery:-"
                        for tdata in t:
                            y=y+tdata.grocery    
                  elif result=="entertainment":
                        x="Total expense on entertainment:-"
                        for tdata in t:
                           y=y+tdata.entertainment
                  elif result=='vehicle':
                        x="Total expense on vehicle:-"
                        for tdata in t:
                           y=y+tdata.vehicle
                  elif result=='food':
                        x="Total expense on food:-"
                        for tdata in t:
                           y=y+tdata.food
                  elif result=='miscellaneous':
	                x="Total expense on miscellaneous:-"
                        for tdata in t:
                           y=y+tdata.miscellaneous   
                  return render(request,'record/collect_data.html',{'data':y,'title':x})
           else:
                return render(request,'record/index.html')  
         else:
          return render(request,'record/index.html')      








