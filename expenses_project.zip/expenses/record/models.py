# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
class Daily_expenses(models.Model):
      grocery=models.FloatField()
      entertainment=models.FloatField()
      vehicle=models.FloatField()
      food=models.FloatField()
      miscellaneous=models.FloatField()
      date=models.DateField()


