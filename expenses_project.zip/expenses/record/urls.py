from django.conf.urls import url,include
from django.views.generic import ListView,DetailView
from . import views
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^add/$',views.add,name='add'),
    url(r'^adddata/$',views.adddata,name='adddata'),
    url(r'^graph1/$',views.graph1,name='graph1'),
    url(r'^graph/$',views.monthaly_basis_graph,name='monthaly_graph'),
    url(r'^add1/$',views.add1,name='add1'),
    url(r'^check/$',views.display,name='display'),
    url(r'^display/$',views.check_req,name='display1'),    
]
