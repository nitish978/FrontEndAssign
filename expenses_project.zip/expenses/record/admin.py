# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Daily_expenses
admin.site.register(Daily_expenses)
# Register your models here.
